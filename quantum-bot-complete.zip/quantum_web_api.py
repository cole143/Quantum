"""
Quantum Web API Server
Created by: Cole Sorokolit and Nic McLeod

FastAPI backend for Quantum web application.
Provides RESTful API endpoints for tax calculations, FDIC info, and more.

Installation:
    pip install fastapi uvicorn python-multipart

Usage:
    uvicorn quantum_web_api:app --reload --host 0.0.0.0 --port 8000

API Documentation (auto-generated):
    http://localhost:8000/docs
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
import uvicorn
import os
from pathlib import Path

from quantum_engine import QuantumEngine, FilingStatus


# Initialize FastAPI app
app = FastAPI(
    title="Quantum Financial Assistant API",
    description="Professional financial calculations and education by Cole Sorokolit and Nic McLeod",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware for web access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Quantum engine
quantum = QuantumEngine(memory_path='./data/web_memory.json')

# Mount static files (HTML, CSS, JS)
static_dir = Path(__file__).parent / "static"
if static_dir.exists():
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# ============================================================================
# Pydantic Models (Request/Response schemas)
# ============================================================================

class TaxCalculationRequest(BaseModel):
    """Request model for tax calculation"""
    income: float = Field(..., gt=0, description="Income amount (must be positive)")
    filing_status: str = Field(..., description="Filing status (Single, Married, MFS, HOH)")
    year: int = Field(2025, ge=2024, le=2025, description="Tax year (2024 or 2025)")
    is_gross_income: bool = Field(False, description="Is this gross income before deductions?")
    user_id: Optional[str] = Field(None, description="Optional user identifier for memory")
    
    class Config:
        schema_extra = {
            "example": {
                "income": 75000,
                "filing_status": "Single",
                "year": 2025,
                "is_gross_income": False,
                "user_id": "user123"
            }
        }


class TaxCalculationResponse(BaseModel):
    """Response model for tax calculation"""
    total_tax: float
    effective_rate: float
    marginal_rate: float
    breakdown: List[Dict[str, Any]]
    filing_status: str
    year: int
    taxable_income: float
    summary: str
    disclaimer: str
    calculation_id: Optional[str] = None


class FDICInfoResponse(BaseModel):
    """Response model for FDIC information"""
    coverage_limit: int
    coverage_per: str
    covered_accounts: List[str]
    not_covered: List[str]
    ownership_categories: List[str]
    key_points: List[str]
    summary: str
    disclaimer: str


class HealthCheckResponse(BaseModel):
    """Health check response"""
    status: str
    version: str
    timestamp: str
    creators: str


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    detail: Optional[str] = None
    timestamp: str


# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main web application"""
    
    html_file = static_dir / "index.html" if static_dir.exists() else None
    
    if html_file and html_file.exists():
        return html_file.read_text()
    
    # Fallback HTML if static files not found
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Quantum Financial Assistant</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                line-height: 1.6;
            }
            h1 { color: #2c3e50; }
            .info { background: #e3f2fd; padding: 15px; border-radius: 8px; margin: 20px 0; }
            .link { color: #1976d2; text-decoration: none; }
            code { background: #f5f5f5; padding: 2px 6px; border-radius: 3px; }
        </style>
    </head>
    <body>
        <h1>🤖 Quantum Financial Assistant API</h1>
        <p>Created by <strong>Cole Sorokolit</strong> and <strong>Nic McLeod</strong></p>
        
        <div class="info">
            <h3>📚 API Documentation</h3>
            <p>Interactive API docs: <a href="/docs" class="link">/docs</a></p>
            <p>ReDoc documentation: <a href="/redoc" class="link">/redoc</a></p>
        </div>
        
        <h3>🚀 Quick Start</h3>
        <p>Calculate tax with a POST request:</p>
        <code>POST /api/calculate-tax</code>
        
        <h3>🔗 Endpoints</h3>
        <ul>
            <li><code>GET /health</code> - Health check</li>
            <li><code>POST /api/calculate-tax</code> - Calculate federal income tax</li>
            <li><code>GET /api/fdic-info</code> - Get FDIC insurance information</li>
            <li><code>GET /api/creators</code> - Learn about Quantum's creators</li>
        </ul>
        
        <p style="margin-top: 40px; color: #666; font-size: 0.9em;">
            ⚠️ For educational purposes only. Not financial advice.
        </p>
    </body>
    </html>
    """


@app.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": "2.0.0",
        "timestamp": datetime.now().isoformat(),
        "creators": "Cole Sorokolit and Nic McLeod"
    }


@app.post("/api/calculate-tax", response_model=TaxCalculationResponse)
async def calculate_tax(request: TaxCalculationRequest):
    """
    Calculate federal income tax
    
    This endpoint calculates federal income tax based on:
    - Income amount
    - Filing status
    - Tax year (2024 or 2025)
    - Whether income is gross (before deductions)
    
    Returns detailed breakdown including:
    - Total tax owed
    - Effective tax rate
    - Marginal tax rate
    - Tax breakdown by bracket
    - Legal disclaimer
    """
    
    try:
        # Generate user_id if not provided
        user_id = request.user_id or f"web_user_{datetime.now().timestamp()}"
        
        # Calculate tax
        result = quantum.calculate_tax(
            income=request.income,
            filing_status=request.filing_status,
            year=request.year,
            user_id=user_id,
            is_gross_income=request.is_gross_income
        )
        
        # Convert to response model
        response = TaxCalculationResponse(
            **result.to_dict(),
            calculation_id=user_id
        )
        
        return response
        
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@app.get("/api/fdic-info", response_model=FDICInfoResponse)
async def get_fdic_info(user_id: Optional[str] = None):
    """
    Get FDIC insurance information
    
    Returns comprehensive information about FDIC insurance including:
    - Coverage limits ($250,000)
    - What accounts are covered
    - What is NOT covered
    - Ownership categories
    - Key points to remember
    - Legal disclaimer
    """
    
    try:
        user_id = user_id or f"web_user_{datetime.now().timestamp()}"
        
        info = quantum.get_fdic_info(user_id=user_id)
        
        return FDICInfoResponse(**info)
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@app.get("/api/creators")
async def get_creators(detailed: bool = False):
    """
    Get information about Quantum's creators
    
    Parameters:
    - detailed: If True, returns detailed information
    
    Returns information about Cole Sorokolit and Nic McLeod
    """
    
    return {
        "creators": "Cole Sorokolit and Nic McLeod",
        "message": quantum.get_creator_info(detailed=detailed),
        "version": "2.0.0",
        "purpose": "Financial education and calculations"
    }


@app.get("/api/filing-statuses")
async def get_filing_statuses():
    """Get list of valid filing statuses"""
    
    return {
        "filing_statuses": [
            {
                "value": "Single",
                "aliases": ["single", "s"],
                "description": "Single filer"
            },
            {
                "value": "Married Filing Jointly",
                "aliases": ["married", "mfj", "married filing jointly"],
                "description": "Married couple filing together"
            },
            {
                "value": "Married Filing Separately",
                "aliases": ["mfs", "married filing separately"],
                "description": "Married couple filing separately"
            },
            {
                "value": "Head of Household",
                "aliases": ["hoh", "head of household"],
                "description": "Unmarried with dependents"
            }
        ]
    }


@app.get("/api/tax-years")
async def get_tax_years():
    """Get available tax years"""
    
    return {
        "available_years": [2024, 2025],
        "current_year": 2025,
        "note": "Tax brackets are updated annually based on IRS data"
    }


# ============================================================================
# Error Handlers
# ============================================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "timestamp": datetime.now().isoformat()
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "timestamp": datetime.now().isoformat()
        }
    )


# ============================================================================
# Startup/Shutdown Events
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Run on server startup"""
    print("=" * 60)
    print("🚀 Quantum Web API Starting...")
    print("   Created by Cole Sorokolit and Nic McLeod")
    print("=" * 60)
    print(f"📊 Version: 2.0.0")
    print(f"🔗 API Docs: http://localhost:8000/docs")
    print(f"📖 ReDoc: http://localhost:8000/redoc")
    print(f"🏠 Home: http://localhost:8000")
    print("=" * 60)
    
    # Ensure data directory exists
    Path("./data").mkdir(exist_ok=True)


@app.on_event("shutdown")
async def shutdown_event():
    """Run on server shutdown"""
    print("\n👋 Quantum Web API shutting down...")
    quantum.memory.save_memory()
    print("✅ Memory saved")


# ============================================================================
# Main Entry Point
# ============================================================================

def main():
    """Run the server"""
    
    # Check if running in production
    is_production = os.getenv("ENVIRONMENT") == "production"
    
    uvicorn.run(
        "quantum_web_api:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=not is_production,
        log_level="info"
    )


if __name__ == "__main__":
    main()
