// Quantum Financial Assistant - JavaScript
// Created by: Cole Sorokolit and Nic McLeod

// ============================================================================
// Configuration
// ============================================================================

const API_BASE_URL = window.location.origin;

// ============================================================================
// Tax Calculator
// ============================================================================

const taxForm = document.getElementById('tax-form');
const taxResults = document.getElementById('tax-results');
const taxError = document.getElementById('tax-error');

taxForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Hide previous results/errors
    taxResults.style.display = 'none';
    taxError.style.display = 'none';
    
    // Get form data
    const income = parseFloat(document.getElementById('income').value);
    const filingStatus = document.getElementById('filing-status').value;
    const taxYear = parseInt(document.getElementById('tax-year').value);
    const isGross = document.getElementById('is-gross').checked;
    
    // Show loading state
    const submitBtn = taxForm.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');
    
    submitBtn.disabled = true;
    btnText.style.display = 'none';
    btnLoading.style.display = 'inline-flex';
    
    try {
        // Make API request
        const response = await fetch(`${API_BASE_URL}/api/calculate-tax`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                income: income,
                filing_status: filingStatus,
                year: taxYear,
                is_gross_income: isGross
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || errorData.detail || 'Calculation failed');
        }
        
        const data = await response.json();
        
        // Display results
        displayTaxResults(data);
        
    } catch (error) {
        // Display error
        taxError.textContent = `Error: ${error.message}`;
        taxError.style.display = 'block';
        
        // Scroll to error
        taxError.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        
    } finally {
        // Reset button
        submitBtn.disabled = false;
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';
    }
});

function displayTaxResults(data) {
    // Update summary cards
    document.getElementById('total-tax').textContent = formatCurrency(data.total_tax);
    document.getElementById('effective-rate').textContent = `${data.effective_rate.toFixed(2)}%`;
    document.getElementById('marginal-rate').textContent = `${data.marginal_rate.toFixed(0)}%`;
    
    // Update breakdown
    const breakdownContent = document.getElementById('breakdown-content');
    breakdownContent.innerHTML = '';
    
    data.breakdown.forEach((item) => {
        const breakdownItem = document.createElement('div');
        breakdownItem.className = 'breakdown-item';
        breakdownItem.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong>${item.bracket}</strong> bracket: 
                    ${formatCurrency(item.range_start)} to 
                    ${item.range_end === Infinity ? 'and above' : formatCurrency(item.range_end)}
                </div>
                <div style="text-align: right;">
                    <div><strong>${formatCurrency(item.tax)}</strong></div>
                    <div style="font-size: 0.9em; color: var(--text-secondary);">
                        on ${formatCurrency(item.taxable_amount)}
                    </div>
                </div>
            </div>
        `;
        breakdownContent.appendChild(breakdownItem);
    });
    
    // Update summary text
    document.getElementById('summary-text').textContent = data.summary;
    
    // Update disclaimer
    document.getElementById('tax-disclaimer').textContent = data.disclaimer;
    
    // Show results
    taxResults.style.display = 'block';
    
    // Scroll to results
    taxResults.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ============================================================================
// FDIC Information
// ============================================================================

const loadFdicBtn = document.getElementById('load-fdic-btn');
const fdicResults = document.getElementById('fdic-results');
const fdicError = document.getElementById('fdic-error');

loadFdicBtn.addEventListener('click', async () => {
    // Hide previous results/errors
    fdicResults.style.display = 'none';
    fdicError.style.display = 'none';
    
    // Show loading state
    loadFdicBtn.disabled = true;
    loadFdicBtn.textContent = 'Loading...';
    
    try {
        // Make API request
        const response = await fetch(`${API_BASE_URL}/api/fdic-info`);
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || 'Failed to load FDIC information');
        }
        
        const data = await response.json();
        
        // Display results
        displayFdicResults(data);
        
    } catch (error) {
        // Display error
        fdicError.textContent = `Error: ${error.message}`;
        fdicError.style.display = 'block';
        
    } finally {
        // Reset button
        loadFdicBtn.disabled = false;
        loadFdicBtn.textContent = 'Reload FDIC Information';
    }
});

function displayFdicResults(data) {
    // Update coverage info
    document.getElementById('fdic-limit').textContent = formatCurrency(data.coverage_limit);
    document.getElementById('fdic-coverage-per').textContent = data.coverage_per;
    
    // Update covered accounts
    const coveredList = document.getElementById('fdic-covered');
    coveredList.innerHTML = '';
    data.covered_accounts.forEach((account) => {
        const li = document.createElement('li');
        li.textContent = account;
        coveredList.appendChild(li);
    });
    
    // Update not covered
    const notCoveredList = document.getElementById('fdic-not-covered');
    notCoveredList.innerHTML = '';
    data.not_covered.forEach((item) => {
        const li = document.createElement('li');
        li.textContent = item;
        notCoveredList.appendChild(li);
    });
    
    // Update key points
    const keyPointsList = document.getElementById('fdic-key-points');
    keyPointsList.innerHTML = '';
    data.key_points.forEach((point) => {
        const li = document.createElement('li');
        li.textContent = point;
        keyPointsList.appendChild(li);
    });
    
    // Update disclaimer
    document.getElementById('fdic-disclaimer').textContent = data.disclaimer;
    
    // Show results
    fdicResults.style.display = 'block';
    
    // Scroll to results
    fdicResults.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

// ============================================================================
// Utility Functions
// ============================================================================

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

// ============================================================================
// Smooth Scrolling for Navigation
// ============================================================================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ============================================================================
// Number Input Formatting
// ============================================================================

const incomeInput = document.getElementById('income');

incomeInput.addEventListener('blur', function() {
    if (this.value) {
        // Remove any existing commas
        const number = this.value.replace(/,/g, '');
        if (!isNaN(number) && number !== '') {
            this.value = number;
        }
    }
});

// ============================================================================
// Form Validation
// ============================================================================

// Add validation messages
const inputs = document.querySelectorAll('.form-input[required]');

inputs.forEach(input => {
    input.addEventListener('invalid', function(e) {
        e.preventDefault();
        this.classList.add('invalid');
    });
    
    input.addEventListener('input', function() {
        this.classList.remove('invalid');
    });
});

// Add custom validation styles
const style = document.createElement('style');
style.textContent = `
    .form-input.invalid {
        border-color: var(--error-color);
    }
    
    .form-input.invalid:focus {
        box-shadow: 0 0 0 3px rgba(244, 67, 54, 0.1);
    }
`;
document.head.appendChild(style);

// ============================================================================
// Initialize Page
// ============================================================================

console.log('🤖 Quantum Financial Assistant');
console.log('Created by Cole Sorokolit and Nic McLeod');
console.log('Version: 2.0.0');

// Log API connection
fetch(`${API_BASE_URL}/health`)
    .then(response => response.json())
    .then(data => {
        console.log('✅ Connected to Quantum API');
        console.log(`   Status: ${data.status}`);
        console.log(`   Version: ${data.version}`);
        console.log(`   Creators: ${data.creators}`);
    })
    .catch(error => {
        console.error('❌ Could not connect to Quantum API');
        console.error('   Make sure the backend server is running');
        console.error('   Run: uvicorn quantum_web_api:app --reload');
    });
