"""
Quantum Bot - Core Engine
Created by: Cole Sorokolit and Nic McLeod
Version: 2.0.0

This is the main engine that powers all Quantum bot implementations.
It handles tax calculations, document extraction, FDIC info, and memory management.
"""

import json
import hashlib
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, asdict
from enum import Enum


class FilingStatus(Enum):
    """Federal tax filing statuses"""
    SINGLE = "Single"
    MARRIED_FILING_JOINTLY = "Married Filing Jointly"
    MARRIED_FILING_SEPARATELY = "Married Filing Separately"
    HEAD_OF_HOUSEHOLD = "Head of Household"


@dataclass
class TaxBracket:
    """Tax bracket definition"""
    rate: float
    range_start: int
    range_end: Optional[int]
    
    def __repr__(self):
        end = f"${self.range_end:,}" if self.range_end else "and above"
        return f"{self.rate*100:.0f}% bracket: ${self.range_start:,} to {end}"


@dataclass
class TaxCalculationResult:
    """Result of a tax calculation"""
    total_tax: float
    effective_rate: float
    marginal_rate: float
    breakdown: List[Dict[str, Any]]
    filing_status: str
    year: int
    taxable_income: float
    summary: str
    disclaimer: str
    
    def to_dict(self):
        return asdict(self)


@dataclass
class ClientProfile:
    """Client profile for memory/context"""
    client_id: str
    created_at: str
    last_updated: str
    consent: Dict[str, Any]
    personal: Dict[str, Any]
    history: Dict[str, List]
    
    def to_dict(self):
        return asdict(self)


class QuantumKnowledgeBase:
    """
    Manages all knowledge files and tax data
    """
    
    def __init__(self):
        self.tax_brackets_2025 = self._load_2025_tax_brackets()
        self.tax_brackets_2024 = self._load_2024_tax_brackets()
        self.standard_deductions = self._load_standard_deductions()
        self.disclaimers = self._load_disclaimers()
        self.creator_info = self._load_creator_info()
        self.fdic_info = self._load_fdic_info()
    
    def _load_2025_tax_brackets(self) -> Dict[FilingStatus, List[TaxBracket]]:
        """Load 2025 federal tax brackets"""
        return {
            FilingStatus.SINGLE: [
                TaxBracket(0.10, 0, 11925),
                TaxBracket(0.12, 11925, 48475),
                TaxBracket(0.22, 48475, 103350),
                TaxBracket(0.24, 103350, 197300),
                TaxBracket(0.32, 197300, 250525),
                TaxBracket(0.35, 250525, 626350),
                TaxBracket(0.37, 626350, None)
            ],
            FilingStatus.MARRIED_FILING_JOINTLY: [
                TaxBracket(0.10, 0, 23850),
                TaxBracket(0.12, 23850, 96950),
                TaxBracket(0.22, 96950, 206700),
                TaxBracket(0.24, 206700, 394600),
                TaxBracket(0.32, 394600, 501050),
                TaxBracket(0.35, 501050, 751600),
                TaxBracket(0.37, 751600, None)
            ],
            FilingStatus.MARRIED_FILING_SEPARATELY: [
                TaxBracket(0.10, 0, 11925),
                TaxBracket(0.12, 11925, 48475),
                TaxBracket(0.22, 48475, 103350),
                TaxBracket(0.24, 103350, 197300),
                TaxBracket(0.32, 197300, 250525),
                TaxBracket(0.35, 250525, 375800),
                TaxBracket(0.37, 375800, None)
            ],
            FilingStatus.HEAD_OF_HOUSEHOLD: [
                TaxBracket(0.10, 0, 17000),
                TaxBracket(0.12, 17000, 64850),
                TaxBracket(0.22, 64850, 103350),
                TaxBracket(0.24, 103350, 197300),
                TaxBracket(0.32, 197300, 250500),
                TaxBracket(0.35, 250500, 626350),
                TaxBracket(0.37, 626350, None)
            ]
        }
    
    def _load_2024_tax_brackets(self) -> Dict[FilingStatus, List[TaxBracket]]:
        """Load 2024 federal tax brackets"""
        return {
            FilingStatus.SINGLE: [
                TaxBracket(0.10, 0, 11600),
                TaxBracket(0.12, 11600, 47150),
                TaxBracket(0.22, 47150, 100525),
                TaxBracket(0.24, 100525, 191950),
                TaxBracket(0.32, 191950, 243725),
                TaxBracket(0.35, 243725, 609350),
                TaxBracket(0.37, 609350, None)
            ],
            FilingStatus.MARRIED_FILING_JOINTLY: [
                TaxBracket(0.10, 0, 23200),
                TaxBracket(0.12, 23200, 94300),
                TaxBracket(0.22, 94300, 201050),
                TaxBracket(0.24, 201050, 383900),
                TaxBracket(0.32, 383900, 487450),
                TaxBracket(0.35, 487450, 731200),
                TaxBracket(0.37, 731200, None)
            ],
            FilingStatus.MARRIED_FILING_SEPARATELY: [
                TaxBracket(0.10, 0, 11600),
                TaxBracket(0.12, 11600, 47150),
                TaxBracket(0.22, 47150, 100525),
                TaxBracket(0.24, 100525, 191950),
                TaxBracket(0.32, 191950, 243725),
                TaxBracket(0.35, 243725, 365600),
                TaxBracket(0.37, 365600, None)
            ],
            FilingStatus.HEAD_OF_HOUSEHOLD: [
                TaxBracket(0.10, 0, 16550),
                TaxBracket(0.12, 16550, 63100),
                TaxBracket(0.22, 63100, 100500),
                TaxBracket(0.24, 100500, 191950),
                TaxBracket(0.32, 191950, 243700),
                TaxBracket(0.35, 243700, 609350),
                TaxBracket(0.37, 609350, None)
            ]
        }
    
    def _load_standard_deductions(self) -> Dict[int, Dict[FilingStatus, int]]:
        """Load standard deductions by year"""
        return {
            2025: {
                FilingStatus.SINGLE: 15000,
                FilingStatus.MARRIED_FILING_JOINTLY: 30000,
                FilingStatus.MARRIED_FILING_SEPARATELY: 15000,
                FilingStatus.HEAD_OF_HOUSEHOLD: 22500
            },
            2024: {
                FilingStatus.SINGLE: 14600,
                FilingStatus.MARRIED_FILING_JOINTLY: 29200,
                FilingStatus.MARRIED_FILING_SEPARATELY: 14600,
                FilingStatus.HEAD_OF_HOUSEHOLD: 21900
            }
        }
    
    def _load_disclaimers(self) -> Dict[str, str]:
        """Load all legal disclaimers"""
        return {
            'tax_calculation': (
                "⚠️ TAX CALCULATION DISCLAIMER: This calculation is for educational and "
                "informational purposes only. It provides an estimate based on the information "
                "provided and may not account for all deductions, credits, state taxes, or "
                "individual circumstances. Tax laws are complex and subject to change. "
                "Consult a licensed tax professional or CPA for personalized tax advice and "
                "official tax preparation. This tool does not constitute professional tax advice."
            ),
            'fdic_insurance': (
                "⚠️ FDIC INSURANCE DISCLOSURE: This information is educational only and based on "
                "FDIC rules as of December 2025. FDIC insurance rules can be complex, especially "
                "regarding different ownership categories and joint accounts. Coverage limits and "
                "rules are subject to change. For specific questions about your accounts and coverage, "
                "contact your bank directly or visit FDIC.gov for official information."
            ),
            'general_financial': (
                "⚠️ GENERAL DISCLAIMER: I am Quantum, an AI assistant created by Cole Sorokolit "
                "and Nic McLeod for educational purposes. I am not a licensed financial advisor, "
                "tax professional, attorney, or investment advisor. The information provided is "
                "for educational purposes only and should not be considered personalized financial, "
                "tax, legal, or investment advice. Always consult with qualified professionals "
                "before making financial decisions."
            )
        }
    
    def _load_creator_info(self) -> Dict[str, str]:
        """Load creator information"""
        return {
            'creators': 'Cole Sorokolit and Nic McLeod',
            'response_short': 'I was created and developed by Cole Sorokolit and Nic McLeod.',
            'response_detailed': (
                'Quantum was created and developed by Cole Sorokolit and Nic McLeod. '
                'They designed Quantum as a specialized financial assistant to help with '
                'tax calculations, FDIC insurance information, and general financial education.'
            )
        }
    
    def _load_fdic_info(self) -> Dict[str, Any]:
        """Load FDIC insurance information"""
        return {
            'coverage_limit': 250000,
            'coverage_per': 'per depositor, per insured bank, per ownership category',
            'covered_accounts': [
                'Checking accounts',
                'Savings accounts',
                'Money market deposit accounts (MMDAs)',
                'Certificates of deposit (CDs)',
                'Cashier\'s checks',
                'Money orders'
            ],
            'not_covered': [
                'Stocks',
                'Bonds',
                'Mutual funds',
                'Cryptocurrency',
                'Annuities',
                'Life insurance policies',
                'Safe deposit box contents',
                'U.S. Treasury bills, bonds, or notes'
            ],
            'ownership_categories': [
                'Single accounts (one owner)',
                'Joint accounts (multiple owners)',
                'Retirement accounts (IRAs, 401(k) rollovers)',
                'Revocable trust accounts',
                'Irrevocable trust accounts',
                'Employee benefit plan accounts',
                'Corporation/Partnership/Unincorporated Association accounts',
                'Government accounts'
            ],
            'key_points': [
                'Each ownership category is insured separately up to $250,000',
                'You can have more than $250,000 insured at one bank by using different ownership categories',
                'Joint accounts: Each co-owner gets $250,000 coverage (so $500,000 total for 2 owners)',
                'Multiple accounts in same category at same bank share the $250,000 limit',
                'Coverage is automatic - no need to apply',
                'Only at FDIC-insured banks (look for FDIC sign)'
            ]
        }
    
    def get_tax_brackets(self, year: int, filing_status: FilingStatus) -> List[TaxBracket]:
        """Get tax brackets for a specific year and filing status"""
        if year == 2025:
            return self.tax_brackets_2025[filing_status]
        elif year == 2024:
            return self.tax_brackets_2024[filing_status]
        else:
            raise ValueError(f"Tax data not available for year {year}. Available: 2024, 2025")
    
    def get_standard_deduction(self, year: int, filing_status: FilingStatus) -> int:
        """Get standard deduction for year and filing status"""
        if year not in self.standard_deductions:
            raise ValueError(f"Standard deduction data not available for year {year}")
        return self.standard_deductions[year][filing_status]


class QuantumMemoryManager:
    """
    Manages client profiles and calculation history
    """
    
    def __init__(self, memory_path: str = './quantum_memory.json'):
        self.memory_path = Path(memory_path)
        self.memory = self._load_memory()
    
    def _load_memory(self) -> Dict:
        """Load memory from disk"""
        if self.memory_path.exists():
            with open(self.memory_path, 'r') as f:
                return json.load(f)
        return {
            'profiles': {},
            'calculations': {},
            'extractions': {}
        }
    
    def save_memory(self):
        """Save memory to disk"""
        # Ensure directory exists
        self.memory_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(self.memory_path, 'w') as f:
            json.dump(self.memory, f, indent=2)
    
    def get_profile(self, user_id: str) -> Optional[ClientProfile]:
        """Get user profile"""
        profile_data = self.memory['profiles'].get(user_id)
        if profile_data:
            return ClientProfile(**profile_data)
        return None
    
    def create_profile(self, user_id: str) -> ClientProfile:
        """Create new user profile"""
        now = datetime.now().isoformat()
        
        profile = ClientProfile(
            client_id=user_id,
            created_at=now,
            last_updated=now,
            consent={
                'store_profile': True,
                'data_retention_days': 365
            },
            personal={},
            history={
                'calculations': [],
                'extractions': [],
                'queries': []
            }
        )
        
        self.memory['profiles'][user_id] = profile.to_dict()
        self.save_memory()
        
        return profile
    
    def update_profile(self, user_id: str, updates: Dict):
        """Update user profile"""
        profile = self.get_profile(user_id)
        
        if not profile:
            profile = self.create_profile(user_id)
        
        profile.last_updated = datetime.now().isoformat()
        
        # Merge updates
        if 'personal' in updates:
            profile.personal.update(updates['personal'])
        
        self.memory['profiles'][user_id] = profile.to_dict()
        self.save_memory()
    
    def add_calculation(self, user_id: str, calc_type: str, result: Dict):
        """Add calculation to history"""
        calc_id = self._generate_id()
        
        self.memory['calculations'][calc_id] = {
            'calculation_id': calc_id,
            'user_id': user_id,
            'type': calc_type,
            'result': result,
            'timestamp': datetime.now().isoformat()
        }
        
        # Add to user's history
        profile = self.get_profile(user_id)
        if profile:
            profile.history['calculations'].append(calc_id)
            self.memory['profiles'][user_id] = profile.to_dict()
        
        self.save_memory()
    
    def get_calculation_history(self, user_id: str, limit: int = 10) -> List[Dict]:
        """Get user's calculation history"""
        profile = self.get_profile(user_id)
        
        if not profile:
            return []
        
        calc_ids = profile.history.get('calculations', [])[-limit:]
        
        return [
            self.memory['calculations'].get(calc_id)
            for calc_id in calc_ids
            if calc_id in self.memory['calculations']
        ]
    
    @staticmethod
    def _generate_id() -> str:
        """Generate unique ID"""
        import uuid
        return str(uuid.uuid4())


class QuantumEngine:
    """
    Main Quantum calculation and processing engine
    """
    
    def __init__(self, memory_path: str = './quantum_memory.json'):
        self.kb = QuantumKnowledgeBase()
        self.memory = QuantumMemoryManager(memory_path)
        
        # Personality traits
        self.personality = {
            'professional_yet_approachable': True,
            'patient_and_educational': True,
            'clear_and_concise': True,
            'helpful_without_pushy': True,
            'financially_savvy_not_condescending': True
        }
    
    def calculate_tax(
        self,
        income: float,
        filing_status: str,
        year: int = 2025,
        user_id: Optional[str] = None,
        is_gross_income: bool = False
    ) -> TaxCalculationResult:
        """
        Calculate federal income tax
        
        Args:
            income: Income amount (taxable or gross)
            filing_status: Filing status string
            year: Tax year (2024 or 2025)
            user_id: Optional user ID for memory
            is_gross_income: Whether income is gross (before standard deduction)
            
        Returns:
            TaxCalculationResult with full breakdown
        """
        
        # Parse filing status
        fs = self._parse_filing_status(filing_status)
        
        # Apply standard deduction if gross income
        taxable_income = income
        if is_gross_income:
            std_deduction = self.kb.get_standard_deduction(year, fs)
            taxable_income = max(0, income - std_deduction)
        
        # Get tax brackets
        brackets = self.kb.get_tax_brackets(year, fs)
        
        # Calculate tax progressively
        total_tax = 0
        breakdown = []
        
        for i, bracket in enumerate(brackets):
            # Determine taxable amount in this bracket
            bracket_start = bracket.range_start
            bracket_end = bracket.range_end if bracket.range_end else float('inf')
            
            if taxable_income <= bracket_start:
                break
            
            taxable_in_bracket = min(
                taxable_income - bracket_start,
                bracket_end - bracket_start
            )
            
            if taxable_in_bracket > 0:
                tax_in_bracket = taxable_in_bracket * bracket.rate
                total_tax += tax_in_bracket
                
                breakdown.append({
                    'bracket': f"{bracket.rate * 100:.0f}%",
                    'range_start': bracket_start,
                    'range_end': bracket_end if bracket_end != float('inf') else taxable_income,
                    'taxable_amount': taxable_in_bracket,
                    'tax': tax_in_bracket,
                    'description': (
                        f"${taxable_in_bracket:,.2f} at {bracket.rate * 100:.0f}% = "
                        f"${tax_in_bracket:,.2f}"
                    )
                })
        
        # Calculate rates
        effective_rate = (total_tax / taxable_income * 100) if taxable_income > 0 else 0
        marginal_rate = float(breakdown[-1]['bracket'].rstrip('%')) if breakdown else 0
        
        # Create summary
        summary = (
            f"For ${taxable_income:,.2f} taxable income ({fs.value}, {year}), "
            f"your federal income tax is ${total_tax:,.2f}. "
            f"This is an effective rate of {effective_rate:.2f}%, "
            f"even though your marginal rate is {marginal_rate:.0f}%."
        )
        
        if is_gross_income:
            std_ded = self.kb.get_standard_deduction(year, fs)
            summary = (
                f"Starting with ${income:,.2f} gross income and applying the "
                f"${std_ded:,} standard deduction gives ${taxable_income:,.2f} taxable income. " +
                summary
            )
        
        # Create result
        result = TaxCalculationResult(
            total_tax=total_tax,
            effective_rate=effective_rate,
            marginal_rate=marginal_rate,
            breakdown=breakdown,
            filing_status=fs.value,
            year=year,
            taxable_income=taxable_income,
            summary=summary,
            disclaimer=self.kb.disclaimers['tax_calculation']
        )
        
        # Save to memory
        if user_id:
            self.memory.add_calculation(
                user_id=user_id,
                calc_type='tax_calculation',
                result=result.to_dict()
            )
        
        return result
    
    def get_fdic_info(self, user_id: Optional[str] = None) -> Dict[str, Any]:
        """Get FDIC insurance information"""
        
        info = self.kb.fdic_info.copy()
        info['disclaimer'] = self.kb.disclaimers['fdic_insurance']
        
        # Add formatted summary
        info['summary'] = (
            f"FDIC insurance protects deposits up to ${info['coverage_limit']:,} "
            f"{info['coverage_per']}. This means your money is safe even if your "
            f"bank fails. The coverage is automatic at FDIC-insured banks."
        )
        
        # Log query to memory
        if user_id:
            profile = self.memory.get_profile(user_id)
            if not profile:
                profile = self.memory.create_profile(user_id)
            
            profile.history['queries'].append({
                'type': 'fdic_info',
                'timestamp': datetime.now().isoformat()
            })
            
            self.memory.memory['profiles'][user_id] = profile.to_dict()
            self.memory.save_memory()
        
        return info
    
    def get_creator_info(self, detailed: bool = False) -> str:
        """Get creator information"""
        
        if detailed:
            return self.kb.creator_info['response_detailed']
        return self.kb.creator_info['response_short']
    
    def format_tax_calculation(self, result: TaxCalculationResult, format_type: str = 'detailed') -> str:
        """
        Format tax calculation result for display
        
        Args:
            result: TaxCalculationResult object
            format_type: 'detailed', 'summary', or 'simple'
            
        Returns:
            Formatted string
        """
        
        if format_type == 'simple':
            return (
                f"**Federal Income Tax Calculation ({result.year})**\n"
                f"Filing Status: {result.filing_status}\n"
                f"Taxable Income: ${result.taxable_income:,.2f}\n"
                f"**Total Tax: ${result.total_tax:,.2f}**\n"
                f"Effective Rate: {result.effective_rate:.2f}%\n"
                f"Marginal Rate: {result.marginal_rate:.0f}%"
            )
        
        elif format_type == 'summary':
            return (
                f"**Federal Income Tax - {result.year}**\n"
                f"{result.filing_status}\n\n"
                f"{result.summary}\n\n"
                f"**Breakdown:**\n" +
                "\n".join([f"• {item['description']}" for item in result.breakdown]) +
                f"\n\n**Total: ${result.total_tax:,.2f}**"
            )
        
        else:  # detailed
            output = (
                f"**📊 Federal Income Tax Calculation - {result.year}**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"**Filing Status:** {result.filing_status}\n"
                f"**Taxable Income:** ${result.taxable_income:,.2f}\n\n"
                f"**Tax Breakdown by Bracket:**\n"
            )
            
            for item in result.breakdown:
                end = f"${item['range_end']:,.0f}" if item['range_end'] != float('inf') else "and above"
                output += (
                    f"• ${item['range_start']:,} to {end} at {item['bracket']}\n"
                    f"  Taxable: ${item['taxable_amount']:,.2f} → Tax: ${item['tax']:,.2f}\n"
                )
            
            output += (
                f"\n**━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━**\n"
                f"**Total Federal Tax:** ${result.total_tax:,.2f}\n"
                f"**Effective Tax Rate:** {result.effective_rate:.2f}%\n"
                f"**Marginal Tax Rate:** {result.marginal_rate:.0f}%\n\n"
                f"💡 **What this means:**\n"
                f"While you're in the {result.marginal_rate:.0f}% tax bracket, "
                f"your actual tax rate on your total income is {result.effective_rate:.2f}% "
                f"because only portions of your income are taxed at the higher rates.\n\n"
            )
            
            return output
    
    def format_fdic_info(self, info: Dict[str, Any], format_type: str = 'detailed') -> str:
        """Format FDIC information for display"""
        
        if format_type == 'simple':
            return (
                f"**🏦 FDIC Insurance**\n"
                f"Coverage: ${info['coverage_limit']:,} {info['coverage_per']}\n\n"
                f"**Covered:** {', '.join(info['covered_accounts'][:3])} and more\n"
                f"**Not Covered:** {', '.join(info['not_covered'][:3])} and more"
            )
        
        else:  # detailed
            output = (
                f"**🏦 FDIC Insurance Information**\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{info['summary']}\n\n"
                f"**Coverage Amount:**\n"
                f"• ${info['coverage_limit']:,} {info['coverage_per']}\n\n"
                f"**What's Covered:**\n"
            )
            
            for account in info['covered_accounts']:
                output += f"✅ {account}\n"
            
            output += "\n**What's NOT Covered:**\n"
            
            for item in info['not_covered']:
                output += f"❌ {item}\n"
            
            output += "\n**Key Points to Remember:**\n"
            
            for point in info['key_points']:
                output += f"• {point}\n"
            
            output += "\n**Ownership Categories:**\n"
            
            for category in info['ownership_categories']:
                output += f"• {category}\n"
            
            return output
    
    def _parse_filing_status(self, status: str) -> FilingStatus:
        """Parse filing status string to enum"""
        
        status_clean = status.upper().replace(' ', '_').replace('-', '_')
        
        status_map = {
            'SINGLE': FilingStatus.SINGLE,
            'S': FilingStatus.SINGLE,
            'MARRIED': FilingStatus.MARRIED_FILING_JOINTLY,
            'MARRIED_FILING_JOINTLY': FilingStatus.MARRIED_FILING_JOINTLY,
            'MFJ': FilingStatus.MARRIED_FILING_JOINTLY,
            'MARRIED_JOINTLY': FilingStatus.MARRIED_FILING_JOINTLY,
            'MARRIED_FILING_SEPARATELY': FilingStatus.MARRIED_FILING_SEPARATELY,
            'MFS': FilingStatus.MARRIED_FILING_SEPARATELY,
            'MARRIED_SEPARATELY': FilingStatus.MARRIED_FILING_SEPARATELY,
            'HEAD_OF_HOUSEHOLD': FilingStatus.HEAD_OF_HOUSEHOLD,
            'HOH': FilingStatus.HEAD_OF_HOUSEHOLD,
            'HEAD': FilingStatus.HEAD_OF_HOUSEHOLD
        }
        
        if status_clean in status_map:
            return status_map[status_clean]
        
        raise ValueError(
            f"Invalid filing status: '{status}'. "
            f"Valid options: Single, Married Filing Jointly, "
            f"Married Filing Separately, Head of Household"
        )
    
    def help_message(self) -> str:
        """Generate help message"""
        
        return """
**🤖 Quantum Financial Assistant**
Created by Cole Sorokolit and Nic McLeod

I can help you with:

**💰 Tax Calculations**
• Calculate federal income tax (2024-2025)
• Show tax bracket breakdowns
• Explain marginal vs effective rates
• Apply standard deductions

**🏦 FDIC Insurance**
• Explain coverage limits ($250,000)
• List covered account types
• Describe ownership categories
• Clarify what's protected

**📊 Financial Education**
• Answer tax questions
• Explain financial concepts
• Provide educational information

**Commands (examples):**
• "Calculate tax on $75,000 income, single, 2025"
• "What's FDIC insurance?"
• "Who created you?"
• "Help"

**Important:** I provide educational information only. 
Always consult licensed professionals for personalized advice.
"""


# Quick test if run directly
if __name__ == "__main__":
    print("Quantum Engine Test\n" + "="*50)
    
    # Initialize engine
    engine = QuantumEngine()
    
    # Test tax calculation
    print("\n1. Testing Tax Calculation...")
    result = engine.calculate_tax(
        income=75000,
        filing_status="Single",
        year=2025,
        user_id="test_user_1"
    )
    
    print(engine.format_tax_calculation(result, format_type='detailed'))
    print(f"\n{result.disclaimer}")
    
    # Test FDIC info
    print("\n" + "="*50)
    print("\n2. Testing FDIC Information...")
    fdic_info = engine.get_fdic_info(user_id="test_user_1")
    
    print(engine.format_fdic_info(fdic_info, format_type='detailed'))
    print(f"\n{fdic_info['disclaimer']}")
    
    # Test creator info
    print("\n" + "="*50)
    print("\n3. Testing Creator Information...")
    print(engine.get_creator_info(detailed=True))
    
    print("\n" + "="*50)
    print("\n✅ All tests passed!")
    print(f"\nMemory saved to: {engine.memory.memory_path}")
