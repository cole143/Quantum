"""
Quantum CLI (Command Line Interface)
Created by: Cole Sorokolit and Nic McLeod

A simple command-line version of Quantum financial assistant.
Perfect for quick calculations and testing.

Usage:
    python quantum_cli.py
"""

from quantum_engine import QuantumEngine
import sys


class QuantumCLI:
    """Command-line interface for Quantum"""
    
    def __init__(self):
        self.engine = QuantumEngine(memory_path='./data/cli_memory.json')
        self.user_id = "cli_user"
        self.running = True
    
    def print_banner(self):
        """Print welcome banner"""
        print("\n" + "=" * 60)
        print("🤖  QUANTUM FINANCIAL ASSISTANT")
        print("    Created by Cole Sorokolit and Nic McLeod")
        print("=" * 60)
        print("\nType 'help' for commands or 'quit' to exit\n")
    
    def print_help(self):
        """Print help information"""
        help_text = """
📋 AVAILABLE COMMANDS:

Tax Calculations:
  tax <income> <status> <year>     Calculate federal income tax
  Example: tax 75000 single 2025
  
  Statuses: single, married, mfs, hoh

FDIC Information:
  fdic                              Show FDIC insurance info

General:
  help                              Show this help message
  about                             Learn about Quantum's creators
  history                           Show your calculation history
  clear                             Clear screen
  quit / exit                       Exit Quantum

💡 Tips:
  • Income can be written with commas: 75,000
  • Year defaults to 2025 if not specified
  • Use 'married' for Married Filing Jointly

⚠️  All calculations are for educational purposes only.
    Consult a licensed professional for personalized advice.
"""
        print(help_text)
    
    def print_about(self):
        """Print about information"""
        print("\n" + "=" * 60)
        print("👥 ABOUT QUANTUM")
        print("=" * 60)
        print(f"\n{self.engine.get_creator_info(detailed=True)}")
        print("\nVersion: 2.0.0")
        print("Release Date: December 2025")
        print("\nCapabilities:")
        print("  • Federal income tax calculations (2024-2025)")
        print("  • FDIC insurance information")
        print("  • Financial education")
        print("  • Memory/context management")
        print("\n" + "=" * 60 + "\n")
    
    def handle_tax_command(self, args):
        """Handle tax calculation command"""
        
        if len(args) < 2:
            print("❌ Usage: tax <income> <filing_status> [year]")
            print("Example: tax 75000 single 2025")
            return
        
        try:
            # Parse income (remove commas)
            income = float(args[0].replace(',', ''))
            filing_status = args[1]
            year = int(args[2]) if len(args) > 2 else 2025
            
            print(f"\n⏳ Calculating tax for ${income:,.2f}...")
            
            # Calculate
            result = self.engine.calculate_tax(
                income=income,
                filing_status=filing_status,
                year=year,
                user_id=self.user_id
            )
            
            # Display result
            print("\n" + "=" * 60)
            formatted = self.engine.format_tax_calculation(result, format_type='detailed')
            print(formatted)
            print("=" * 60)
            
            # Show disclaimer
            print(f"\n⚠️  DISCLAIMER:")
            print(result.disclaimer)
            print("\n")
            
        except ValueError as e:
            print(f"\n❌ Error: {e}\n")
        except Exception as e:
            print(f"\n❌ Unexpected error: {e}\n")
    
    def handle_fdic_command(self):
        """Handle FDIC information command"""
        
        print("\n⏳ Loading FDIC information...")
        
        try:
            info = self.engine.get_fdic_info(user_id=self.user_id)
            
            print("\n" + "=" * 60)
            formatted = self.engine.format_fdic_info(info, format_type='detailed')
            print(formatted)
            print("=" * 60)
            
            print(f"\n⚠️  DISCLAIMER:")
            print(info['disclaimer'])
            print("\n")
            
        except Exception as e:
            print(f"\n❌ Error: {e}\n")
    
    def handle_history_command(self):
        """Show calculation history"""
        
        history = self.engine.memory.get_calculation_history(
            user_id=self.user_id,
            limit=10
        )
        
        if not history:
            print("\n📊 No calculation history yet.")
            print("    Try running a tax calculation!\n")
            return
        
        print("\n" + "=" * 60)
        print("📊 YOUR CALCULATION HISTORY")
        print("=" * 60 + "\n")
        
        for i, calc in enumerate(history, 1):
            calc_type = calc['type'].replace('_', ' ').title()
            timestamp = calc['timestamp']
            result = calc['result']
            
            print(f"{i}. {calc_type} - {timestamp[:19]}")
            
            if calc['type'] == 'tax_calculation':
                print(f"   Income: ${result['taxable_income']:,.2f}")
                print(f"   Tax: ${result['total_tax']:,.2f}")
                print(f"   Rate: {result['effective_rate']:.2f}%")
            
            print()
    
    def clear_screen(self):
        """Clear the screen"""
        import os
        os.system('cls' if os.name == 'nt' else 'clear')
        self.print_banner()
    
    def parse_command(self, user_input):
        """Parse and execute user command"""
        
        # Clean input
        user_input = user_input.strip()
        
        if not user_input:
            return
        
        # Split into command and args
        parts = user_input.split()
        command = parts[0].lower()
        args = parts[1:]
        
        # Execute command
        if command in ['quit', 'exit', 'q']:
            print("\n👋 Thanks for using Quantum! Goodbye.\n")
            self.running = False
        
        elif command == 'help':
            self.print_help()
        
        elif command == 'about':
            self.print_about()
        
        elif command == 'tax':
            self.handle_tax_command(args)
        
        elif command == 'fdic':
            self.handle_fdic_command()
        
        elif command == 'history':
            self.handle_history_command()
        
        elif command == 'clear':
            self.clear_screen()
        
        elif command == 'creator' or command == 'creators':
            print(f"\n{self.engine.get_creator_info(detailed=True)}\n")
        
        else:
            print(f"\n❌ Unknown command: '{command}'")
            print("   Type 'help' to see available commands\n")
    
    def run(self):
        """Main run loop"""
        
        self.print_banner()
        
        while self.running:
            try:
                # Get user input
                user_input = input("Quantum> ")
                
                # Parse and execute
                self.parse_command(user_input)
                
            except KeyboardInterrupt:
                print("\n\n👋 Interrupted. Use 'quit' to exit gracefully.\n")
            except EOFError:
                print("\n\n👋 Goodbye!\n")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")


def main():
    """Main entry point"""
    
    cli = QuantumCLI()
    cli.run()


if __name__ == "__main__":
    main()
