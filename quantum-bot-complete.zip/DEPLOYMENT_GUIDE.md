# Quantum Bot - Multi-Platform Deployment Guide
**Created by: Cole Sorokolit and Nic McLeod**

Complete guide for deploying Quantum to any platform - from simple hosting to enterprise scale.

---

## 📋 Table of Contents

1. [Quick Deployment Options](#quick-deployment-options)
2. [Web App Deployment](#web-app-deployment)
3. [Cloud Platform Guides](#cloud-platform-guides)
4. [Discord Bot Deployment](#discord-bot-deployment)
5. [Custom Domain Setup](#custom-domain-setup)
6. [SSL/HTTPS Configuration](#sslhttps-configuration)
7. [Database Setup](#database-setup)
8. [Scaling & Load Balancing](#scaling--load-balancing)
9. [Monitoring & Maintenance](#monitoring--maintenance)
10. [Cost Breakdown](#cost-breakdown)

---

## 🎯 Quick Deployment Options

### **Option 1: Free & Fast (Recommended for Testing)**
**Platform:** Render.com (Free tier)  
**Time:** 10 minutes  
**Cost:** $0/month  
**Best for:** Testing, personal use, demos

### **Option 2: Production Ready**
**Platform:** DigitalOcean App Platform  
**Time:** 20 minutes  
**Cost:** $5-12/month  
**Best for:** Small business, client projects

### **Option 3: Enterprise Scale**
**Platform:** AWS (EC2 + RDS + CloudFront)  
**Time:** 2-4 hours  
**Cost:** $50-200/month  
**Best for:** High traffic, enterprise clients

---

## 🌐 Web App Deployment

### Prerequisites

1. **Your Quantum files:**
   - `quantum_engine.py`
   - `quantum_web_api.py`
   - `requirements.txt`
   - `static/` folder (HTML, CSS, JS)

2. **Git repository:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   ```

3. **GitHub account** (or GitLab/Bitbucket)

---

## Method 1: Render.com (FREE - Easiest!)

### Step 1: Push to GitHub

```bash
# Create new repo on GitHub, then:
git remote add origin https://github.com/yourusername/quantum-bot.git
git branch -M main
git push -u origin main
```

### Step 2: Deploy on Render

1. Go to https://render.com
2. Sign up (free)
3. Click "New +" → "Web Service"
4. Connect your GitHub repository
5. Configure:

```yaml
Name: quantum-financial-assistant
Environment: Python 3
Build Command: pip install -r requirements.txt
Start Command: uvicorn quantum_web_api:app --host 0.0.0.0 --port $PORT
```

6. Click "Create Web Service"
7. Wait 2-3 minutes for deployment
8. Your app will be live at: `https://quantum-financial-assistant.onrender.com`

**✅ Done! Your web app is live and FREE!**

### Limitations of Free Tier:
- Sleeps after 15 min of inactivity (wakes in ~30 seconds)
- 750 hours/month free
- Shared resources

### Upgrade to Paid ($7/month):
- Always on
- Faster performance
- No sleep
- Custom domain

---

## Method 2: Railway.app (Easy + $5 Credit)

### Step 1: Setup

1. Go to https://railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Select your Quantum repository

### Step 2: Configure

Railway auto-detects Python and uses `requirements.txt`.

Add environment variables (if needed):
```
PORT=8000
ENVIRONMENT=production
```

### Step 3: Deploy

- Automatic deployment on push to main branch
- Get free $5 credit (enough for 1 month)
- After credit: ~$5/month

**Your app:** `https://quantum-bot-production.up.railway.app`

---

## Method 3: Heroku (Classic Option)

### Step 1: Create Procfile

```bash
# Create Procfile in your project root
echo "web: uvicorn quantum_web_api:app --host 0.0.0.0 --port \$PORT" > Procfile
```

### Step 2: Deploy

```bash
# Install Heroku CLI
# Mac: brew install heroku/brew/heroku
# Windows: Download from heroku.com

# Login
heroku login

# Create app
heroku create quantum-financial-bot

# Deploy
git push heroku main

# Open
heroku open
```

**Cost:** $7/month (after free trial)

---

## Method 4: DigitalOcean App Platform

### Step 1: Create Account

1. Go to https://digitalocean.com
2. Sign up (get $200 credit with special links)

### Step 2: Deploy

1. Click "Apps" → "Create App"
2. Connect GitHub
3. Select repository
4. Configure:

```yaml
Name: quantum-bot
HTTP Port: 8000
HTTP Request Routes: /
Build Command: pip install -r requirements.txt
Run Command: uvicorn quantum_web_api:app --host 0.0.0.0 --port 8000
```

5. Choose plan: **Basic ($5/month)**
6. Launch!

**Your app:** `https://quantum-bot-xxxxx.ondigitalocean.app`

---

## Method 5: Vercel (Frontend + Serverless)

Great for static frontend with serverless backend.

### Step 1: Create vercel.json

```json
{
  "builds": [
    {
      "src": "quantum_web_api.py",
      "use": "@vercel/python"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "quantum_web_api.py"
    }
  ]
}
```

### Step 2: Deploy

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Production
vercel --prod
```

**Cost:** Free for personal, $20/month for team

---

## Method 6: AWS (Professional/Enterprise)

### Architecture

```
┌──────────────┐      ┌──────────────┐      ┌──────────────┐
│  CloudFront  │─────►│  EC2/ECS     │─────►│  RDS         │
│  (CDN)       │      │  (App)       │      │  (Database)  │
└──────────────┘      └──────────────┘      └──────────────┘
```

### Step 1: EC2 Instance

```bash
# Launch Ubuntu EC2 instance (t2.micro for free tier)

# SSH into instance
ssh -i yourkey.pem ubuntu@your-instance-ip

# Install dependencies
sudo apt update
sudo apt install python3-pip nginx -y

# Clone your repo
git clone https://github.com/yourusername/quantum-bot.git
cd quantum-bot

# Install Python packages
pip3 install -r requirements.txt

# Run with systemd (persistent)
sudo nano /etc/systemd/system/quantum.service
```

### quantum.service file:

```ini
[Unit]
Description=Quantum Financial Assistant
After=network.target

[Service]
User=ubuntu
WorkingDirectory=/home/ubuntu/quantum-bot
ExecStart=/usr/bin/python3 -m uvicorn quantum_web_api:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
# Start service
sudo systemctl daemon-reload
sudo systemctl start quantum
sudo systemctl enable quantum

# Check status
sudo systemctl status quantum
```

### Step 2: Nginx Reverse Proxy

```bash
sudo nano /etc/nginx/sites-available/quantum
```

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/quantum /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Step 3: Security Group

Allow these ports in AWS Security Group:
- 22 (SSH)
- 80 (HTTP)
- 443 (HTTPS)

**Cost:** ~$10-50/month depending on traffic

---

## Method 7: Google Cloud Run (Serverless)

### Step 1: Create Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD uvicorn quantum_web_api:app --host 0.0.0.0 --port $PORT
```

### Step 2: Deploy

```bash
# Install gcloud CLI
# https://cloud.google.com/sdk/docs/install

# Build and deploy
gcloud run deploy quantum-bot \
    --source . \
    --region us-central1 \
    --allow-unauthenticated \
    --port 8000
```

**Cost:** Pay per request (very cheap for low traffic)
- First 2 million requests free
- $0.40 per million requests after

---

## Method 8: Azure App Service

### Step 1: Create App Service

```bash
# Install Azure CLI
# https://docs.microsoft.com/en-us/cli/azure/install-azure-cli

# Login
az login

# Create resource group
az group create --name quantum-rg --location eastus

# Create app service plan
az appservice plan create \
    --name quantum-plan \
    --resource-group quantum-rg \
    --sku B1 \
    --is-linux

# Create web app
az webapp create \
    --resource-group quantum-rg \
    --plan quantum-plan \
    --name quantum-financial-assistant \
    --runtime "PYTHON|3.11"

# Deploy
az webapp up --name quantum-financial-assistant
```

**Cost:** $13-55/month

---

## 🔧 Discord Bot Deployment

### Option 1: Same Server as Web App

```python
# In quantum_web_api.py, add:

import asyncio
import threading
from quantum_discord_bot import bot

def run_discord_bot():
    asyncio.run(bot.run(os.getenv('DISCORD_BOT_TOKEN')))

@app.on_event("startup")
async def startup():
    # Start Discord bot in background thread
    discord_thread = threading.Thread(target=run_discord_bot)
    discord_thread.daemon = True
    discord_thread.start()
```

### Option 2: Separate Service

Deploy Discord bot separately on:
- **Replit** (easiest, always-on with Hacker plan)
- **Heroku Worker Dyno** ($7/month)
- **DigitalOcean Droplet** ($4/month)
- **AWS EC2** (free tier)

### Replit Deployment (Recommended for Discord Bot)

1. Go to https://replit.com
2. Create new Repl → Python
3. Upload `quantum_discord_bot.py` and `quantum_engine.py`
4. Add Secrets:
   - `DISCORD_BOT_TOKEN`: your token
5. Click "Run"
6. Upgrade to "Always On" ($7/month) or use UptimeRobot to ping

---

## 🌍 Custom Domain Setup

### Step 1: Buy Domain

- **Namecheap**: ~$10/year
- **Google Domains**: ~$12/year
- **Cloudflare**: ~$10/year (includes CDN)

### Step 2: Configure DNS

#### For Render.com:
```
Type: CNAME
Name: www
Value: quantum-financial-assistant.onrender.com
```

#### For DigitalOcean:
```
Type: A
Name: @
Value: your-droplet-ip
```

### Step 3: Add Domain in Platform

Most platforms have "Custom Domains" section:
1. Add domain
2. Verify DNS
3. Auto SSL certificate

---

## 🔒 SSL/HTTPS Configuration

### Automatic SSL (Recommended)

Most platforms provide free SSL:
- ✅ Render.com: Automatic
- ✅ Railway: Automatic
- ✅ Vercel: Automatic
- ✅ Heroku: Automatic with custom domain

### Manual SSL (AWS/DigitalOcean)

Use Let's Encrypt (FREE):

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com

# Auto-renewal
sudo certbot renew --dry-run
```

**Certificate auto-renews every 90 days!**

---

## 💾 Database Setup

### SQLite (Default - Fine for Start)

Already included! Quantum uses JSON files by default.

### PostgreSQL (Recommended for Production)

#### Option 1: Managed Database

**Render.com:**
- Free tier: 1GB
- Paid: $7/month for 10GB

**DigitalOcean:**
- $15/month for managed PostgreSQL

**AWS RDS:**
- $15-30/month

#### Option 2: Setup on Your Server

```bash
# Install PostgreSQL
sudo apt install postgresql postgresql-contrib

# Create database
sudo -u postgres createdb quantum_db
sudo -u postgres createuser quantum_user
sudo -u postgres psql -c "ALTER USER quantum_user WITH PASSWORD 'your_password';"

# Update quantum_engine.py to use PostgreSQL
# (You'd need to modify code to use SQLAlchemy)
```

---

## 📊 Scaling & Load Balancing

### When You Need to Scale

- 1,000+ daily users
- 10,000+ calculations/day
- Response time > 2 seconds
- Multiple geographic regions

### Horizontal Scaling

```
┌─────────────┐
│ Load        │
│ Balancer    │
└──────┬──────┘
       │
   ┌───┴───┬───────┬────────┐
   │       │       │        │
┌──▼──┐ ┌──▼──┐ ┌──▼──┐  ┌──▼──┐
│ App │ │ App │ │ App │  │ App │
│  1  │ │  2  │ │  3  │  │  4  │
└─────┘ └─────┘ └─────┘  └─────┘
```

**Platforms with auto-scaling:**
- AWS Elastic Beanstalk
- Google Cloud Run
- Azure App Service
- Heroku (with add-on)

### Caching Layer

Add Redis for faster responses:

```bash
# Add to requirements.txt
redis>=5.0.0

# In quantum_engine.py
import redis

cache = redis.Redis(host='localhost', port=6379, decode_responses=True)

def calculate_tax(income, status, year):
    # Check cache first
    cache_key = f"tax:{income}:{status}:{year}"
    cached = cache.get(cache_key)
    if cached:
        return json.loads(cached)
    
    # Calculate and cache
    result = do_calculation(income, status, year)
    cache.setex(cache_key, 3600, json.dumps(result))  # Cache 1 hour
    return result
```

---

## 📈 Monitoring & Maintenance

### Essential Monitoring

1. **Uptime Monitoring**
   - **UptimeRobot** (Free): https://uptimerobot.com
   - Pings your site every 5 minutes
   - Email alerts if down

2. **Error Tracking**
   - **Sentry** (Free tier): https://sentry.io
   ```python
   # Add to quantum_web_api.py
   import sentry_sdk
   
   sentry_sdk.init("your-dsn-here")
   ```

3. **Performance Monitoring**
   - **New Relic** (Free tier)
   - **Datadog** (Free tier)

### Health Check Endpoint

Already included in `quantum_web_api.py`:
```
GET /health
```

Configure uptime monitor to check this endpoint.

### Logging

```python
# Add to quantum_web_api.py
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('quantum.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger('quantum')
```

View logs:
```bash
# Render/Railway: View in dashboard
# Heroku: heroku logs --tail
# AWS/DO: tail -f quantum.log
```

---

## 💰 Cost Breakdown

### Free Options (Good for Testing)

| Platform | Storage | Bandwidth | Features | Limitations |
|----------|---------|-----------|----------|-------------|
| **Render.com Free** | 512MB | 100GB/mo | Auto-deploy, SSL | Sleeps after 15min |
| **Railway $5 credit** | 1GB | Unlimited | Fast, Easy | After credit: $5/mo |
| **Replit Free** | 500MB | Unlimited | Browser IDE | Public code |

### Low-Cost Production ($5-15/month)

| Platform | Monthly Cost | Features |
|----------|--------------|----------|
| **Render Starter** | $7 | Always on, 512MB RAM |
| **Railway** | $5-10 | Pay per use |
| **DigitalOcean** | $5-12 | Full control, 1GB RAM |
| **Heroku Hobby** | $7 | Easy, reliable |

### Professional ($15-50/month)

| Setup | Monthly Cost | Specs |
|-------|--------------|-------|
| **DigitalOcean** | $15-20 | 2GB RAM, managed DB |
| **AWS (small)** | $20-30 | EC2 t2.small, RDS |
| **Google Cloud** | $15-25 | Cloud Run + SQL |

### Enterprise ($50-200+/month)

| Setup | Monthly Cost | Features |
|-------|--------------|----------|
| **AWS (full)** | $50-200 | Load balancer, CDN, RDS, multi-region |
| **Azure** | $60-150 | App Service + SQL |
| **GCP** | $50-180 | Cloud Run, Load Balancer, Cloud SQL |

---

## 🎯 Recommended Deployment Path

### Phase 1: Testing (FREE)
**Platform:** Render.com Free  
**Time:** 10 minutes  
**Purpose:** Test, demo, share with friends

### Phase 2: Beta (​$5-7/month)
**Platform:** Railway or DigitalOcean Basic  
**Time:** 20 minutes  
**Purpose:** Beta users, collect feedback

### Phase 3: Production ($15-30/month)
**Platform:** DigitalOcean + Managed DB  
**Time:** 1 hour  
**Purpose:** Real users, reliable service

### Phase 4: Scale ($50+/month)
**Platform:** AWS/GCP with auto-scaling  
**Time:** 4+ hours  
**Purpose:** High traffic, multiple regions

---

## 🚀 Quick Start Checklist

### For Web App:

- [ ] Push code to GitHub
- [ ] Choose platform (Render recommended)
- [ ] Deploy (10 minutes)
- [ ] Test health endpoint
- [ ] Test tax calculation
- [ ] Test FDIC info
- [ ] Setup uptime monitoring
- [ ] (Optional) Add custom domain
- [ ] (Optional) Setup error tracking

### For Discord Bot:

- [ ] Get Discord bot token
- [ ] Push code to GitHub
- [ ] Choose platform (Replit recommended)
- [ ] Set environment variable
- [ ] Deploy and run
- [ ] Invite bot to server
- [ ] Test commands
- [ ] Setup always-on (if free tier sleeps)

---

## 🆘 Troubleshooting

### App Won't Start

```bash
# Check logs
render logs  # Render
heroku logs --tail  # Heroku
railway logs  # Railway

# Common issues:
# 1. Wrong start command
# 2. Missing dependencies
# 3. Wrong Python version
# 4. Port not set correctly
```

### Database Errors

```python
# Ensure data directory exists
import os
os.makedirs('./data', exist_ok=True)
```

### Static Files Not Loading

```python
# In quantum_web_api.py, verify:
app.mount("/static", StaticFiles(directory="static"), name="static")

# Ensure static/ folder is in your repo
```

### CORS Errors

Already handled in `quantum_web_api.py`:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set to your domain in production
    ...
)
```

---

## 📚 Additional Resources

- **FastAPI Docs**: https://fastapi.tiangolo.com
- **Uvicorn Docs**: https://www.uvicorn.org
- **Render Docs**: https://render.com/docs
- **DigitalOcean Tutorials**: https://docs.digitalocean.com
- **AWS Free Tier**: https://aws.amazon.com/free

---

## ✅ Next Steps

1. **Deploy Web App** (Start with Render.com free)
2. **Test thoroughly**
3. **Setup monitoring**
4. **Get feedback from users**
5. **Upgrade as needed**
6. **Add custom domain when ready**

---

**Created by Cole Sorokolit and Nic McLeod**  
**Quantum Financial Assistant v2.0.0**

*For the best website experience, I recommend starting with **Render.com** (free tier) or **Railway** ($5/month after credit). Both are incredibly easy and perfect for your needs!*
