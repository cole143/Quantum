# Quantum Bot - Complete Implementation
**Created by: Cole Sorokolit and Nic McLeod**

A professional financial assistant AI bot that provides tax calculations, FDIC insurance information, and financial education.

---

## 🎯 What's Included

This package contains **4 complete bot implementations**:

1. **quantum_engine.py** - Core calculation engine (works standalone)
2. **quantum_cli.py** - Command-line interface
3. **quantum_discord_bot.py** - Discord bot with slash commands
4. **quantum_integrated_framework.md** - Complete documentation (80+ pages)

---

## 🚀 Quick Start

### Option 1: Command-Line Interface (Easiest)

No setup required! Just run:

```bash
python quantum_cli.py
```

Then try:
```
Quantum> tax 75000 single 2025
Quantum> fdic
Quantum> help
```

### Option 2: Discord Bot

1. **Install dependencies:**
```bash
pip install discord.py
```

2. **Get a Discord bot token:**
   - Go to https://discord.com/developers/applications
   - Create New Application
   - Go to "Bot" tab → Add Bot
   - Copy the token

3. **Set your token:**
```bash
# Linux/Mac
export DISCORD_BOT_TOKEN='your_token_here'

# Windows
set DISCORD_BOT_TOKEN=your_token_here
```

4. **Run the bot:**
```bash
python quantum_discord_bot.py
```

5. **Invite to your server:**
   - In Discord Developer Portal, go to OAuth2 → URL Generator
   - Select scopes: `bot`, `applications.commands`
   - Select permissions: Send Messages, Embed Links, Read Message History
   - Copy and visit the generated URL

6. **Use commands:**
```
/tax 75000 Single 2025
/fdic
/help
/about
```

### Option 3: Test the Engine Directly

```bash
python quantum_engine.py
```

This runs built-in tests and shows you how the engine works.

---

## 📋 Features

### Tax Calculations
- ✅ Federal income tax for 2024 and 2025
- ✅ All filing statuses (Single, Married, etc.)
- ✅ Progressive bracket calculations
- ✅ Marginal vs effective rates explained
- ✅ Standard deduction handling
- ✅ Full breakdown by bracket

### FDIC Insurance
- ✅ Coverage limits ($250,000)
- ✅ Ownership categories explained
- ✅ What's covered vs not covered
- ✅ Key points and tips

### Memory System
- ✅ Saves calculation history
- ✅ User profiles with consent
- ✅ Context persistence
- ✅ Privacy-focused

### Legal Compliance
- ✅ Automatic disclaimers
- ✅ Educational purpose statements
- ✅ Professional referral reminders
- ✅ Creator attribution

---

## 🛠️ Installation

### Minimal Installation (CLI only)
```bash
# No dependencies needed!
python quantum_cli.py
```

### Full Installation (All features)
```bash
# Install all dependencies
pip install -r requirements.txt

# Create data directory
mkdir -p data
```

---

## 📖 Usage Examples

### Command-Line Interface

```bash
$ python quantum_cli.py

Quantum> tax 75000 single 2025
⏳ Calculating tax for $75,000.00...

============================================================
📊 Federal Income Tax Calculation - 2025
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Filing Status: Single
Taxable Income: $75,000.00

Tax Breakdown by Bracket:
• $0 to $11,925 at 10%
  Taxable: $11,925.00 → Tax: $1,192.50
• $11,925 to $48,475 at 12%
  Taxable: $36,550.00 → Tax: $4,386.00
• $48,475 to $75,000 at 22%
  Taxable: $26,525.00 → Tax: $5,835.50

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total Federal Tax: $11,414.00
Effective Tax Rate: 15.22%
Marginal Tax Rate: 22%

💡 What this means:
While you're in the 22% tax bracket, your actual tax rate 
on your total income is 15.22% because only portions of 
your income are taxed at the higher rates.
============================================================

Quantum> fdic

🏦 FDIC Insurance Information
[Shows complete FDIC info]

Quantum> history

📊 YOUR CALCULATION HISTORY
1. Tax Calculation - 2024-12-15 15:30:45
   Income: $75,000.00
   Tax: $11,414.00
   Rate: 15.22%
```

### Discord Bot

```
User: /tax 75000 Single 2025

Quantum: [Beautiful embed with:]
💰 Federal Income Tax - 2025

For $75,000.00 taxable income (Single, 2025), 
your federal income tax is $11,414.00...

Total Tax: $11,414.00
Effective Rate: 15.22%
Marginal Rate: 22%

Tax Breakdown:
• $11,925.00 at 10% = $1,192.50
• $36,550.00 at 12% = $4,386.00
• $26,525.00 at 22% = $5,835.50
```

### Python Code (Using Engine Directly)

```python
from quantum_engine import QuantumEngine

# Initialize
engine = QuantumEngine()

# Calculate tax
result = engine.calculate_tax(
    income=75000,
    filing_status="Single",
    year=2025,
    user_id="user123"
)

print(f"Total tax: ${result.total_tax:,.2f}")
print(f"Effective rate: {result.effective_rate:.2f}%")

# Get FDIC info
fdic_info = engine.get_fdic_info(user_id="user123")
print(f"Coverage: ${fdic_info['coverage_limit']:,}")

# Format for display
formatted = engine.format_tax_calculation(result, format_type='detailed')
print(formatted)
```

---

## 📁 File Structure

```
quantum-bot/
├── quantum_engine.py              # Core calculation engine
├── quantum_cli.py                 # Command-line interface
├── quantum_discord_bot.py         # Discord bot
├── requirements.txt               # Dependencies
├── README.md                      # This file
├── quantum_integrated_framework.md  # Complete documentation
│
├── data/                          # Created automatically
│   ├── cli_memory.json           # CLI user data
│   └── discord_memory.json       # Discord user data
│
└── [Your uploaded files]/         # Knowledge base
    ├── QTAX_BRACKETS.txt
    ├── QUANTUM_LEGAL_COMPLIANCE.txt
    ├── STATE_TAX_AND_FINANCE_LAWS.txt
    └── ... (other files)
```

---

## 🎓 How It Works

### Architecture

```
┌─────────────────────────────────────────┐
│         User Interface Layer             │
│  (CLI, Discord, Web, API, etc.)         │
└───────────────┬─────────────────────────┘
                │
┌───────────────▼─────────────────────────┐
│        Quantum Engine Core               │
│  • Tax calculations                      │
│  • FDIC information                      │
│  • Memory management                     │
│  • Legal compliance                      │
└───────────────┬─────────────────────────┘
                │
┌───────────────▼─────────────────────────┐
│       Knowledge Base Layer               │
│  • Tax brackets (2024-2025)              │
│  • Legal disclaimers                     │
│  • Creator information                   │
│  • State tax laws                        │
└──────────────────────────────────────────┘
```

### Tax Calculation Process

1. **Input Validation** - Check filing status, year, income
2. **Bracket Selection** - Get appropriate tax brackets
3. **Progressive Calculation** - Calculate tax tier by tier
4. **Rate Computation** - Calculate effective and marginal rates
5. **Formatting** - Create human-readable output
6. **Disclaimer Injection** - Add legal compliance text
7. **Memory Storage** - Save to user history

---

## ⚙️ Configuration

### Environment Variables

```bash
# Discord Bot Token (required for Discord bot)
DISCORD_BOT_TOKEN=your_token_here

# Optional: Custom memory location
MEMORY_PATH=./custom_path/memory.json
```

### Memory Management

The bot automatically creates a memory file (`quantum_memory.json`) that stores:
- User profiles
- Calculation history
- Query logs

To reset memory, simply delete the file:
```bash
rm data/cli_memory.json
```

---

## 🔒 Privacy & Security

- ✅ All data stored locally (no cloud by default)
- ✅ User consent for data storage
- ✅ Automatic data retention limits (365 days)
- ✅ No PII required for calculations
- ✅ Memory can be cleared at any time
- ✅ All calculations traceable and auditable

---

## 📝 Available Commands

### CLI Commands
```
tax <income> <status> <year>   - Calculate federal income tax
fdic                            - Show FDIC insurance info
about                           - Learn about creators
history                         - Show calculation history
help                            - Show all commands
clear                           - Clear screen
quit                            - Exit Quantum
```

### Discord Slash Commands
```
/tax <income> <status> <year>   - Calculate tax (interactive)
/fdic                            - FDIC information
/help                            - Show help
/about                           - About Quantum
```

### Discord Text Commands
```
!q tax <income> <status> <year>  - Calculate tax
!q fdic                          - FDIC information
!q help                          - Show help
!q about                         - About Quantum
!q history                       - Your calculation history
```

---

## 🎯 Filing Statuses

Valid filing status inputs:

- **Single**: `single`, `s`
- **Married Filing Jointly**: `married`, `mfj`, `married filing jointly`
- **Married Filing Separately**: `mfs`, `married filing separately`
- **Head of Household**: `hoh`, `head of household`

Case-insensitive and flexible!

---

## ⚠️ Important Disclaimers

### Educational Purpose Only
Quantum provides educational information and should not be considered:
- Professional financial advice
- Tax preparation services
- Legal counsel
- Investment recommendations

### Always Consult Professionals
For personalized advice, consult:
- Licensed tax professionals (CPA, EA)
- Certified Financial Planners (CFP)
- Licensed attorneys for legal matters
- Registered investment advisors for investments

### Accuracy Note
While Quantum uses official IRS data (2024-2025 tax brackets), it:
- Does not account for all deductions and credits
- Does not include state/local taxes
- Does not handle complex tax situations
- May not reflect mid-year tax law changes

---

## 🐛 Troubleshooting

### "Module not found" error
```bash
pip install -r requirements.txt
```

### Discord bot won't start
1. Check token is set: `echo $DISCORD_BOT_TOKEN`
2. Verify token is correct (check Discord Developer Portal)
3. Ensure bot has proper permissions

### Memory file errors
```bash
# Create data directory
mkdir -p data

# Or use custom path
export MEMORY_PATH=./my_custom_path/memory.json
```

### "Invalid filing status" error
Use one of: `single`, `married`, `mfs`, `hoh`

---

## 🔄 Updates & Maintenance

### Annual Tax Bracket Updates
Every year (typically October/November):
1. IRS releases new tax brackets
2. Update `QuantumKnowledgeBase._load_202X_tax_brackets()`
3. Test thoroughly
4. Deploy

### Adding New Features
The engine is modular. To add features:
1. Add method to `QuantumEngine` class
2. Update knowledge base if needed
3. Add commands to CLI/Discord bot
4. Update this README

---

## 📚 Additional Resources

- **Full Documentation**: See `quantum_integrated_framework.md` (80+ pages)
- **IRS Tax Information**: https://www.irs.gov
- **FDIC Official Site**: https://www.fdic.gov
- **Discord Bot Guide**: https://discord.com/developers/docs

---

## 👥 Credits

**Created by:**
- **Cole Sorokolit**
- **Nic McLeod**

**Version:** 2.0.0  
**Release Date:** December 2025

---

## 📄 License

This bot is proprietary software created by Cole Sorokolit and Nic McLeod.

---

## 🤝 Support

For questions or issues:
1. Review this README
2. Check the full framework documentation
3. Test with the CLI version first
4. Verify your environment setup

---

## ✨ Quick Reference Card

```
┌─────────────────────────────────────────────────────────┐
│  QUANTUM QUICK REFERENCE                                │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  CLI Start:        python quantum_cli.py                │
│  Discord Start:    python quantum_discord_bot.py        │
│  Test Engine:      python quantum_engine.py             │
│                                                          │
│  Tax Calc:         tax 75000 single 2025                │
│  FDIC Info:        fdic                                 │
│  Help:             help                                 │
│                                                          │
│  Creators:         Cole Sorokolit & Nic McLeod          │
│  Purpose:          Financial Education                   │
│  Disclaimer:       Educational purposes only             │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

**🚀 Ready to use Quantum? Pick a version above and get started!**
