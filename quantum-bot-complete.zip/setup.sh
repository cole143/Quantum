#!/bin/bash
# Quantum Bot Setup Script
# Created by: Cole Sorokolit and Nic McLeod

echo "============================================================"
echo "🤖  QUANTUM BOT SETUP"
echo "    Created by Cole Sorokolit and Nic McLeod"
echo "============================================================"
echo ""

# Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "✅ Found Python $python_version"
echo ""

# Create data directory
echo "Creating data directory..."
mkdir -p data
echo "✅ Data directory created"
echo ""

# Install dependencies (optional)
read -p "Install Discord bot dependencies? (y/n) " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "Installing dependencies..."
    pip install discord.py
    echo "✅ Dependencies installed"
else
    echo "⏭️  Skipping dependency installation"
fi
echo ""

# Test the engine
echo "Testing Quantum engine..."
python3 quantum_engine.py > /dev/null 2>&1
if [ $? -eq 0 ]; then
    echo "✅ Engine test passed"
else
    echo "⚠️  Engine test had warnings (may be normal)"
fi
echo ""

echo "============================================================"
echo "✅ SETUP COMPLETE!"
echo "============================================================"
echo ""
echo "Quick Start Options:"
echo ""
echo "1️⃣  Command-Line Interface (No setup needed):"
echo "    python3 quantum_cli.py"
echo ""
echo "2️⃣  Discord Bot (Requires token):"
echo "    export DISCORD_BOT_TOKEN='your_token_here'"
echo "    python3 quantum_discord_bot.py"
echo ""
echo "3️⃣  Test the Engine:"
echo "    python3 quantum_engine.py"
echo ""
echo "📖 For full instructions, see README.md"
echo ""
echo "============================================================"
