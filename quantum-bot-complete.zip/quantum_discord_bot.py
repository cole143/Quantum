"""
Quantum Discord Bot
Created by: Cole Sorokolit and Nic McLeod

A Discord bot implementation of Quantum financial assistant.
Provides tax calculations, FDIC information, and financial education.

Installation:
    pip install discord.py

Usage:
    python quantum_discord_bot.py

Required Environment Variable:
    DISCORD_BOT_TOKEN=your_bot_token_here
"""

import discord
from discord.ext import commands
from discord import app_commands
import os
from quantum_engine import QuantumEngine
import asyncio


# Initialize bot with proper intents
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(
    command_prefix='!q ',
    intents=intents,
    description='Quantum Financial Assistant by Cole Sorokolit and Nic McLeod'
)

# Initialize Quantum engine
quantum = QuantumEngine(memory_path='./data/discord_memory.json')


@bot.event
async def on_ready():
    """Called when bot is ready"""
    print(f'✅ {bot.user} has connected to Discord!')
    print(f'Connected to {len(bot.guilds)} guilds')
    
    # Sync slash commands
    try:
        synced = await bot.tree.sync()
        print(f'✅ Synced {len(synced)} slash commands')
    except Exception as e:
        print(f'Failed to sync commands: {e}')
    
    # Set bot activity
    await bot.change_presence(
        activity=discord.Activity(
            type=discord.ActivityType.watching,
            name="your finances | /help"
        )
    )


@bot.event
async def on_message(message):
    """Handle messages"""
    # Ignore bot's own messages
    if message.author == bot.user:
        return
    
    # Process commands
    await bot.process_commands(message)


# ============================================================================
# SLASH COMMANDS (Modern Discord UI)
# ============================================================================

@bot.tree.command(name="tax", description="Calculate federal income tax")
@app_commands.describe(
    income="Your taxable income amount",
    filing_status="Your filing status (Single, Married, etc.)",
    year="Tax year (2024 or 2025)",
    is_gross="Is this gross income before deductions?"
)
async def slash_tax(
    interaction: discord.Interaction,
    income: float,
    filing_status: str,
    year: int = 2025,
    is_gross: bool = False
):
    """Calculate federal income tax (slash command)"""
    
    await interaction.response.defer(thinking=True)
    
    try:
        # Calculate tax
        result = quantum.calculate_tax(
            income=income,
            filing_status=filing_status,
            year=year,
            user_id=str(interaction.user.id),
            is_gross_income=is_gross
        )
        
        # Create embed
        embed = discord.Embed(
            title=f"💰 Federal Income Tax - {year}",
            description=result.summary,
            color=discord.Color.blue()
        )
        
        # Add main fields
        embed.add_field(
            name="Total Tax",
            value=f"**${result.total_tax:,.2f}**",
            inline=True
        )
        embed.add_field(
            name="Effective Rate",
            value=f"**{result.effective_rate:.2f}%**",
            inline=True
        )
        embed.add_field(
            name="Marginal Rate",
            value=f"**{result.marginal_rate:.0f}%**",
            inline=True
        )
        
        # Add breakdown
        breakdown_text = "\n".join([
            f"• {item['description']}"
            for item in result.breakdown[:5]  # Limit to 5 brackets
        ])
        
        embed.add_field(
            name="Tax Breakdown",
            value=breakdown_text,
            inline=False
        )
        
        # Add footer with disclaimer
        embed.set_footer(
            text="Disclaimer: For educational purposes only. Consult a tax professional."
        )
        
        await interaction.followup.send(embed=embed)
        
    except ValueError as e:
        await interaction.followup.send(
            f"❌ **Error:** {str(e)}",
            ephemeral=True
        )
    except Exception as e:
        await interaction.followup.send(
            f"❌ **Unexpected error:** {str(e)}",
            ephemeral=True
        )


@bot.tree.command(name="fdic", description="Learn about FDIC insurance")
async def slash_fdic(interaction: discord.Interaction):
    """Get FDIC insurance information (slash command)"""
    
    await interaction.response.defer(thinking=True)
    
    try:
        # Get FDIC info
        info = quantum.get_fdic_info(user_id=str(interaction.user.id))
        
        # Create embed
        embed = discord.Embed(
            title="🏦 FDIC Insurance Information",
            description=info['summary'],
            color=discord.Color.green()
        )
        
        # Coverage
        embed.add_field(
            name="Coverage Limit",
            value=f"**${info['coverage_limit']:,}**\n{info['coverage_per']}",
            inline=False
        )
        
        # What's covered
        covered_text = "\n".join([f"✅ {acc}" for acc in info['covered_accounts'][:5]])
        embed.add_field(
            name="What's Covered",
            value=covered_text,
            inline=True
        )
        
        # What's not covered
        not_covered_text = "\n".join([f"❌ {item}" for item in info['not_covered'][:5]])
        embed.add_field(
            name="What's NOT Covered",
            value=not_covered_text,
            inline=True
        )
        
        # Key points
        key_points_text = "\n".join([f"• {point}" for point in info['key_points'][:3]])
        embed.add_field(
            name="Key Points",
            value=key_points_text,
            inline=False
        )
        
        # Footer
        embed.set_footer(
            text="Visit FDIC.gov for official information"
        )
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(
            f"❌ **Error:** {str(e)}",
            ephemeral=True
        )


@bot.tree.command(name="help", description="Show Quantum help and commands")
async def slash_help(interaction: discord.Interaction):
    """Show help information (slash command)"""
    
    embed = discord.Embed(
        title="🤖 Quantum Financial Assistant",
        description="Created by **Cole Sorokolit** and **Nic McLeod**",
        color=discord.Color.purple()
    )
    
    # Tax commands
    embed.add_field(
        name="💰 Tax Calculations",
        value=(
            "`/tax` - Calculate federal income tax\n"
            "`!q tax <income> <status> <year>` - Text command version\n"
            "Example: `/tax 75000 Single 2025`"
        ),
        inline=False
    )
    
    # FDIC commands
    embed.add_field(
        name="🏦 FDIC Insurance",
        value=(
            "`/fdic` - Learn about FDIC insurance coverage\n"
            "`!q fdic` - Text command version"
        ),
        inline=False
    )
    
    # Info commands
    embed.add_field(
        name="ℹ️ Information",
        value=(
            "`/help` - Show this help message\n"
            "`/about` - Learn about Quantum's creators\n"
            "`!q help` - Text command version"
        ),
        inline=False
    )
    
    # Available filing statuses
    embed.add_field(
        name="📋 Filing Statuses",
        value=(
            "• Single (or S)\n"
            "• Married Filing Jointly (or MFJ, Married)\n"
            "• Married Filing Separately (or MFS)\n"
            "• Head of Household (or HOH)"
        ),
        inline=False
    )
    
    embed.set_footer(
        text="⚠️ For educational purposes only. Consult professionals for advice."
    )
    
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="about", description="Learn about Quantum's creators")
async def slash_about(interaction: discord.Interaction):
    """Show information about creators"""
    
    embed = discord.Embed(
        title="👥 About Quantum",
        description=quantum.get_creator_info(detailed=True),
        color=discord.Color.gold()
    )
    
    embed.add_field(
        name="Creators",
        value="**Cole Sorokolit** and **Nic McLeod**",
        inline=False
    )
    
    embed.add_field(
        name="Purpose",
        value=(
            "Quantum is a specialized financial AI assistant designed to provide:\n"
            "• Tax calculations and education\n"
            "• FDIC insurance information\n"
            "• General financial literacy\n"
            "• Professional-grade calculations"
        ),
        inline=False
    )
    
    embed.add_field(
        name="Important Note",
        value=(
            "Quantum provides educational information only and is not a substitute "
            "for professional financial, tax, or legal advice."
        ),
        inline=False
    )
    
    await interaction.response.send_message(embed=embed)


# ============================================================================
# TEXT COMMANDS (Traditional prefix commands)
# ============================================================================

@bot.command(name='tax')
async def text_tax(ctx, income: float, filing_status: str, year: int = 2025):
    """Calculate federal income tax (text command)"""
    
    async with ctx.typing():
        try:
            # Calculate tax
            result = quantum.calculate_tax(
                income=income,
                filing_status=filing_status,
                year=year,
                user_id=str(ctx.author.id)
            )
            
            # Format and send
            formatted = quantum.format_tax_calculation(result, format_type='detailed')
            
            # Split if too long
            if len(formatted) > 2000:
                # Send in chunks
                chunks = [formatted[i:i+1900] for i in range(0, len(formatted), 1900)]
                for chunk in chunks:
                    await ctx.send(chunk)
            else:
                await ctx.send(formatted)
            
            # Send disclaimer
            await ctx.send(f"⚠️ {result.disclaimer[:500]}...")
            
        except ValueError as e:
            await ctx.send(f"❌ **Error:** {str(e)}")
        except Exception as e:
            await ctx.send(f"❌ **Unexpected error:** {str(e)}")


@bot.command(name='fdic')
async def text_fdic(ctx):
    """Get FDIC insurance information (text command)"""
    
    async with ctx.typing():
        try:
            info = quantum.get_fdic_info(user_id=str(ctx.author.id))
            formatted = quantum.format_fdic_info(info, format_type='detailed')
            
            # Split if too long
            if len(formatted) > 2000:
                chunks = [formatted[i:i+1900] for i in range(0, len(formatted), 1900)]
                for chunk in chunks:
                    await ctx.send(chunk)
            else:
                await ctx.send(formatted)
            
            await ctx.send(f"\n⚠️ {info['disclaimer'][:500]}...")
            
        except Exception as e:
            await ctx.send(f"❌ **Error:** {str(e)}")


@bot.command(name='help')
async def text_help(ctx):
    """Show help information (text command)"""
    
    help_text = quantum.help_message()
    
    help_text += """

**Text Commands (prefix: !q):**
• `!q tax <income> <status> <year>` - Calculate tax
• `!q fdic` - FDIC insurance info
• `!q help` - This message
• `!q about` - About Quantum

**Slash Commands (recommended):**
• `/tax` - Calculate tax (with UI)
• `/fdic` - FDIC info
• `/help` - Help message
• `/about` - About Quantum

Use slash commands for the best experience!
"""
    
    await ctx.send(help_text)


@bot.command(name='about')
async def text_about(ctx):
    """Show information about creators (text command)"""
    
    about_text = f"""
**🤖 About Quantum**

{quantum.get_creator_info(detailed=True)}

**Version:** 2.0.0
**Created:** December 2025

Quantum specializes in:
• Federal tax calculations (2024-2025)
• FDIC insurance education
• Financial literacy
• Professional-grade analysis

**Important:** All information is for educational purposes only.
Always consult licensed professionals for personalized advice.
"""
    
    await ctx.send(about_text)


@bot.command(name='history')
async def text_history(ctx, limit: int = 5):
    """View your calculation history"""
    
    history = quantum.memory.get_calculation_history(
        user_id=str(ctx.author.id),
        limit=limit
    )
    
    if not history:
        await ctx.send("📊 You don't have any calculations yet. Try `/tax` to get started!")
        return
    
    embed = discord.Embed(
        title="📊 Your Calculation History",
        color=discord.Color.blue()
    )
    
    for i, calc in enumerate(history, 1):
        calc_type = calc['type'].replace('_', ' ').title()
        timestamp = calc['timestamp'][:10]  # Just the date
        
        result = calc['result']
        
        if calc['type'] == 'tax_calculation':
            value = (
                f"Income: ${result['taxable_income']:,.2f}\n"
                f"Tax: ${result['total_tax']:,.2f}\n"
                f"Rate: {result['effective_rate']:.2f}%"
            )
        else:
            value = "Query logged"
        
        embed.add_field(
            name=f"{i}. {calc_type} ({timestamp})",
            value=value,
            inline=False
        )
    
    await ctx.send(embed=embed)


# ============================================================================
# ERROR HANDLING
# ============================================================================

@bot.event
async def on_command_error(ctx, error):
    """Handle command errors"""
    
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(
            f"❌ Missing required argument: `{error.param.name}`\n"
            f"Use `!q help` to see correct usage."
        )
    elif isinstance(error, commands.BadArgument):
        await ctx.send(
            f"❌ Invalid argument provided.\n"
            f"Use `!q help` to see correct usage."
        )
    elif isinstance(error, commands.CommandNotFound):
        await ctx.send(
            f"❌ Unknown command. Use `!q help` to see available commands."
        )
    else:
        await ctx.send(f"❌ An error occurred: {str(error)}")
        print(f"Error: {error}")


# ============================================================================
# STARTUP
# ============================================================================

def main():
    """Main entry point"""
    
    # Get bot token
    token = os.getenv('DISCORD_BOT_TOKEN')
    
    if not token:
        print("❌ Error: DISCORD_BOT_TOKEN environment variable not set!")
        print("\nTo set it:")
        print("  Linux/Mac: export DISCORD_BOT_TOKEN='your_token_here'")
        print("  Windows: set DISCORD_BOT_TOKEN=your_token_here")
        print("\nOr create a .env file with:")
        print("  DISCORD_BOT_TOKEN=your_token_here")
        return
    
    print("🚀 Starting Quantum Discord Bot...")
    print("=" * 50)
    
    try:
        bot.run(token)
    except discord.errors.LoginFailure:
        print("❌ Error: Invalid bot token!")
    except Exception as e:
        print(f"❌ Error starting bot: {e}")


if __name__ == "__main__":
    main()
